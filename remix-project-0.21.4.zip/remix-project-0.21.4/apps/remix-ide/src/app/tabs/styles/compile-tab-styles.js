const csjs = require('csjs-inject')

const css = csjs`
  .compilerTabView {
    padding: 2%;
  }
`

module.exports = css
